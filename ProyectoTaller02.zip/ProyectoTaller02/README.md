ProyectoUnity (Space Soccer)
============================

Proyecto mini juego para el curso de programación de videojuegos usando la plataforma Unity.

Objetivo: Intentar llegar a la portería del enemigo sin que ellos consigan hacer que atravieses
la portería del jugador.

Autores: 
-------
        Antonio Álvarez Ramírez
        Blaise Rodríguez Gorrin
        Guillermo Rodríguez Pardo
